Delete all the keys of the currently selected DB.
This command never fails.

The time-complexity for this operation is O(N), N being the number of
keys in the database.

`FLUSHDB ASYNC` (Redis 4.0.0 or greater)
---
See `FLUSHALL` for documentation.

@return

@simple-string-reply
