See `SCAN` for `HSCAN` documentation.
